# yolo_test > 2025-06-25 11:17pm
https://universe.roboflow.com/yolotest-85kxj/yolo_test-13mpl

Provided by a Roboflow user
License: CC BY 4.0

