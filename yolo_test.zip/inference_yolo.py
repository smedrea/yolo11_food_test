from ultralytics import YOLO

# 1) Загружаем обученную модель
model = YOLO("runs/detect/train/weights/best.pt")

# 2) Инференс на видео с пониженным разрешением и шагом кадров
video_path = "C:/My projects/yolo_test/data/3_1.MOV"  # актуальное имя
model.predict(
    source=video_path,
    save=True,
    conf=0.01,
    imgsz=640,        # уменьшили разрешение
    vid_stride=2,     # обрабатываем каждое 2-е изображение
    stream=True,      # потоковая обработка
    name="video_inference"
)

# 3) Инференс на всех кадрах в папке (размер тоже 640)
images_dir = "C:/My projects/yolo_test/data/frames"
model.predict(
    source=images_dir,
    save=True,
    conf=0.01,
    imgsz=640,
    name="image_inference"
)

print("✅ Инференс запущен. Результаты в:")
print("  • runs/detect/video_inference/")
print("  • runs/detect/image_inference/")