import cv2
import os

video_path = 'data/3_1.mov'
output_dir = 'data/frames'

os.makedirs(output_dir, exist_ok=True)

cap = cv2.VideoCapture(video_path)
fps = cap.get(cv2.CAP_PROP_FPS)
frame_rate = int(fps)  # извлечение раз в секунду

frame_count = 0
saved_count = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    if frame_count % frame_rate == 0:
        fname = os.path.join(output_dir, f'frame_{saved_count:04}.jpg')
        cv2.imwrite(fname, frame)
        saved_count += 1

    frame_count += 1

cap.release()
print(f"💾 Сохранено {saved_count} кадров в {output_dir}")