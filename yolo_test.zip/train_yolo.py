from ultralytics import YOLO

model = YOLO("C:/My projects/yolo_test/yolov11n.pt")  # или yolov11.pt, если он у тебя есть

model.train(
    data="C:/My projects/yolo_test/data/data.yaml",
    epochs=50,
    imgsz=640,
    batch=8
)